const mocha = require('mocha');
const assert = require('asset');
describe('Test categories', function() {

    it('adds two numbers together', function() {
        assert(2 + 3 === 5);
    });
});